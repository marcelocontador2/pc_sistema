from fastapi import FastAPI, UploadFile, File, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import os, shutil, io, glob, csv
import psycopg2
import pandas as pd
from fpdf import FPDF
from fpdf.enums import XPos, YPos
from pptx import Presentation
from pptx.util import Inches
from pptx.enum.text import PP_ALIGN
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

app = FastAPI(title="PC - Prestacao de Contas API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DB_CONFIG = {"host": "localhost", "port": 5433, "database": "pc_database",
             "user": "postgres", "password": "pc_admin_2026"}

UPLOAD_DIR = r"C:\Users\Marcelo Medeiros\pc_sistema\pc_storage\uploads_raw"
FRONTEND_DIR = r"C:\Users\Marcelo Medeiros\pc_sistema\pc_frontend"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.get("/", response_class=HTMLResponse)
async def serve_frontend():
    with open(os.path.join(FRONTEND_DIR, "index.html"), encoding="utf-8") as f:
        return f.read()

@app.get("/analise")
async def obter_analise():
    return {"ativo_total": 616607030.65, "passivo_total": 12238786.04,
            "patrimonio_liquido": 604368244.61, "superavit_orcamentario": -70944403.02}

@app.get("/periodos")
async def obter_periodos():
    try:
        conn = psycopg2.connect(**DB_CONFIG); cur = conn.cursor()
        cur.execute("""
            SELECT DISTINCT p.ano, p.periodo_acumulado
            FROM periodo p
            JOIN documento_importado doc ON p.id = doc.periodo_id
            ORDER BY p.ano DESC, p.periodo_acumulado DESC
        """)
        rows = cur.fetchall(); cur.close(); conn.close()
        return [{"ano": r[0], "periodo": r[1], "label": f"{r[0]} - {r[1]}"} for r in rows]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro /periodos: {e}")

def _get_csv_por_tipo(tipo):
    files = glob.glob(os.path.join(UPLOAD_DIR, "*.csv"))
    if tipo == "BALANCO_PATRIMONIAL":
        include, exclude = ["PATRIMONIAL", "BP"], ["FINANCEIRO", "ORCAMENTARIO", "BALANCETE"]
    elif tipo == "BALANCO_FINANCEIRO":
        include, exclude = ["FINANCEIRO", "BF"], ["PATRIMONIAL", "ORCAMENTARIO", "BALANCETE"]
    elif tipo == "BALANCO_ORCAMENTARIO":
        include, exclude = ["ORCAMENTARIO", "BO"], ["PATRIMONIAL", "FINANCEIRO", "BALANCETE"]
    elif tipo == "BALANCETE":
        include, exclude = ["BALANCETE"], ["PATRIMONIAL", "FINANCEIRO", "ORCAMENTARIO"]
    else:
        return None
        
    for f in files:
        name = os.path.basename(f).upper()
        if any(k in name for k in include) and not any(ex in name for ex in exclude):
            return f
            
    for f in files:
        if any(k in f.upper() for k in include):
            return f
    return None

def _ler_csv_generico(filepath):
    dados = []
    with open(filepath, "r", encoding="latin-1") as f:
        reader = csv.reader(f, delimiter=';')
        for row in reader:
            clean = [str(c).replace('\n', ' ').replace('\r', ' ').strip() for c in row]
            dados.append(clean)
    return dados

def _buscar_dados(tipo, ano, periodo):
    if tipo.startswith("BALANCO") or tipo == "BALANCETE":
        return [{"grupo": "Demonstrativo", "valor": 0}] 
        
    conn = psycopg2.connect(**DB_CONFIG); cur = conn.cursor()
    cur.execute(f"""
        SELECT b.codigo_conta, b.descricao_conta, b.saldo_atual, b.natureza_saldo
        FROM balancete_linha b 
        JOIN documento_importado doc ON b.documento_id = doc.id
        JOIN periodo p ON doc.periodo_id = p.id
        WHERE p.ano = %s AND p.periodo_acumulado = %s
        ORDER BY b.codigo_conta
    """, (ano, periodo))
    rows = cur.fetchall(); cur.close(); conn.close()
    return [{"conta": r[0], "descricao": r[1], "valor": float(r[2]) if r[2] is not None else 0.0, "natureza": r[3] or ""} for r in rows]

@app.get("/demonstracoes/{tipo}")
async def obter_demonstracao(tipo: str, ano: int = Query(2026), periodo: str = Query("Jan-Set")):
    try:
        return _buscar_dados(tipo, ano, periodo)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro SQL: {str(e)}")

@app.get("/download/pdf/{tipo}")
async def download_pdf(tipo: str, ano: int = Query(2026), periodo: str = Query("Jan-Set")):
    try:
        csv_path = _get_csv_por_tipo(tipo)
        if not csv_path:
            raise HTTPException(status_code=404, detail=f"Arquivo CSV para {tipo} não encontrado.")
        
        dados_csv = _ler_csv_generico(csv_path)
        
        while dados_csv and not any(str(c).strip() for c in dados_csv[-1]):
            dados_csv.pop()
        
        pdf = FPDF(orientation="L", unit="mm", format="A4")
        pdf.set_auto_page_break(auto=False) 
        
        # Nomes exatos baseados no tipo
        titulos = {
            "BALANCETE": "Balancete Contábil",
            "BALANCO_PATRIMONIAL": "Balanço Patrimonial",
            "BALANCO_ORCAMENTARIO": "Balanço Orçamentário",
            "BALANCO_FINANCEIRO": "Balanço Financeiro",
            "DFC": "Demonstração dos Fluxos de Caixa (DFC)",
            "DVP": "Demonstração das Variações Patrimoniais (DVP)",
            "DMPL": "Demonstração das Mutações do Patrimônio Líquido (DMPL)"
        }
        titulo_pdf = titulos.get(tipo, "Relatório Contábil")
        
        # 1. Encontrar a linha de cabeçalho no CSV
        header_idx = -1
        max_cols = 6
        for i, row in enumerate(dados_csv):
            row_str = " ".join(row).upper()
            if "ESPECIFICA" in row_str or "RECEITAS ORCAMENT" in row_str or "PREVIS" in row_str:
                header_idx = i
                # Conta quantas colunas realmente têm texto para saber o tamanho da tabela
                max_cols = max(len(row), 6) 
                break
                
        if header_idx == -1:
            header_idx = 0 # Fallback
            
        def draw_header(is_first_page=False):
            if is_first_page:
                pdf.set_fill_color(0, 114, 186)
                pdf.rect(10, 10, 277, 20, 'F')
                
                pdf.set_text_color(255, 255, 255)
                pdf.set_font("Helvetica", "B", 14)
                pdf.set_xy(15, 12)
                pdf.cell(0, 6, "COFEN/BR - Conselho Federal de Enfermagem", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                pdf.set_font("Helvetica", "", 9)
                pdf.set_x(15)
                pdf.cell(0, 5, "CNPJ: 47.217.146/0001-57", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                
                pdf.set_xy(200, 12)
                pdf.set_font("Helvetica", "B", 10)
                pdf.cell(85, 6, f"Período: {periodo}/{ano}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="R")
                pdf.set_font("Helvetica", "", 9)
                pdf.set_x(200)
                pdf.cell(85, 5, titulo_pdf, new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="R")
                
                pdf.set_text_color(0, 0, 0)
                pdf.ln(12)
            else:
                pdf.set_font("Helvetica", "I", 8)
                pdf.set_text_color(100, 100, 100)
                pdf.cell(0, 5, f"COFEN/BR - {titulo_pdf} - Período: {periodo}/{ano} (Continuação)", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="R")
                pdf.ln(2)
            
            # Desenha o cabeçalho da tabela baseado no CSV
            pdf.set_fill_color(230, 240, 250)
            pdf.set_font("Helvetica", "B", 7)
            pdf.set_text_color(0, 0, 0)
            
            header_row = dados_csv[header_idx]
            if not any(header_row):
                header_row = ["ESPECIFICAÇÃO"] + [""] * (max_cols - 1)
                
            w_col = 277 / max_cols
            
            for j in range(max_cols):
                txt = header_row[j] if j < len(header_row) else ""
                pdf.cell(w_col, 8, txt[:30], border=0, fill=True, align="C")
            pdf.ln(8)

        pdf.add_page()
        draw_header(is_first_page=True)
        
        def draw_row(row, is_header, is_total, idx):
            num_lines = 1
            if len(row) > 0:
                text = row[0].encode('latin-1', 'replace').decode('latin-1') or " "
                lines = pdf.multi_cell(277/max_cols, 5, text, dry_run=True, output="LINES")
                num_lines = max(num_lines, len(lines))
            
            actual_h = 5 * num_lines
            
            if pdf.get_y() + actual_h > (pdf.h - 15):
                pdf.add_page()
                draw_header(is_first_page=False)
            
            x, y = pdf.get_x(), pdf.get_y()
            
            if is_header: pdf.set_fill_color(240, 248, 255)
            elif is_total: pdf.set_fill_color(250, 250, 250)
            else: pdf.set_fill_color(255, 255, 255) if (idx % 2 == 0) else pdf.set_fill_color(248, 249, 250)
            
            w_col = 277 / max_cols
            pdf.rect(x, y, 277, actual_h, style='F')
            
            pdf.set_draw_color(200, 200, 200)
            pdf.rect(x, y, 277, actual_h, style='D')
            for i in range(1, max_cols):
                pdf.line(x + (i * w_col), y, x + (i * w_col), y + actual_h)
                
            for j in range(max_cols):
                text = row[j].encode('latin-1', 'replace').decode('latin-1') if j < len(row) else ""
                align = "L" if j == 0 else "R"
                
                if align == "L":
                    pdf.set_xy(x + (j * w_col) + 1, y + 0.5)
                    pdf.multi_cell(w_col, 5, text, border=0, align="L")
                else:
                    center_y = y + (actual_h - 5) / 2
                    pdf.set_xy(x + (j * w_col), center_y)
                    pdf.cell(w_col, 5, text[:30], align="R", border=0)
            
            pdf.set_xy(x, y + actual_h)

        for idx, row in enumerate(dados_csv[header_idx+1:]):
            if not any(str(c).strip() for c in row): 
                if pdf.get_y() < (pdf.h - 20): pdf.ln(2)
                continue
            
            row_text = " ".join(row).upper()
            is_header = any(k in row[0].upper() for k in ["ATIVO", "PASSIVO", "PATRIMÔNIO", "COMPENSAÇÕES", "QUADRO", "RECEITAS", "DESPESAS", "INGRESSOS"])
            is_total = "TOTAL" in row_text
            
            if is_header: pdf.set_font("Helvetica", "B", 7.5)
            elif is_total: pdf.set_font("Helvetica", "B", 7)
            else: pdf.set_font("Helvetica", "", 7)
                
            draw_row(row, is_header, is_total, idx)
        
        out = pdf.output()
        pdf_bytes = bytes(out)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao gerar PDF: {str(e)}")
        
    return Response(content=pdf_bytes, media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="relatorio_{tipo}_{ano}.pdf"'})

@app.get("/download/excel/{tipo}")
async def download_excel(tipo: str, ano: int = Query(2026), periodo: str = Query("Jan-Set")):
    try:
        csv_path = _get_csv_por_tipo(tipo)
        if not csv_path:
            raise HTTPException(status_code=404, detail="CSV não encontrado.")
            
        dados_csv = _ler_csv_generico(csv_path)
        while dados_csv and not any(str(c).strip() for c in dados_csv[-1]):
            dados_csv.pop()
            
        header_idx = 0
        max_cols = 6
        for i, row in enumerate(dados_csv):
            row_str = " ".join(row).upper()
            if "ESPECIFICA" in row_str or "RECEITAS ORCAMENT" in row_str:
                header_idx = i
                max_cols = max(len(row), 6)
                break

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = tipo.replace("_", " ").title()

        ws.merge_cells('A1:F1')
        ws['A1'] = "COFEN/BR - Conselho Federal de Enfermagem"
        ws['A1'].font = Font(bold=True, size=14, color="FFFFFF")
        ws['A1'].fill = PatternFill(start_color="0072BA", end_color="0072BA", fill_type="solid")
        ws['A1'].alignment = Alignment(vertical="center")
        
        ws.merge_cells('A2:F2')
        ws['A2'] = f"CNPJ: 47.217.146/0001-57   |   Período: {periodo}/{ano}"
        ws['A2'].font = Font(size=10, color="FFFFFF")
        ws['A2'].fill = PatternFill(start_color="0072BA", end_color="0072BA", fill_type="solid")
        ws['A2'].alignment = Alignment(vertical="center")

        # Cabeçalho
        header_row = dados_csv[header_idx]
        for col_idx, h in enumerate(header_row, start=1):
            cell = ws.cell(row=5, column=col_idx, value=h)
            cell.font = Font(bold=True, color="000000")
            cell.fill = PatternFill(start_color="E6F0FA", end_color="E6F0FA", fill_type="solid")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = openpyxl.styles.Border(bottom=openpyxl.styles.Side(style='thin', color='C8D6DF'), top=openpyxl.styles.Side(style='thin', color='C8D6DF'))

        # Dados
        for row_idx, row in enumerate(dados_csv[header_idx+1:], start=6):
            if not any(str(c).strip() for c in row):
                continue
                
            row_str = " ".join(row).upper()
            is_header = any(k in row[0].upper() for k in ["ATIVO", "PASSIVO", "PATRIMÔNIO", "RECEITAS", "DESPESAS", "INGRESSOS"])
            is_total = "TOTAL" in row_str

            for col_idx, val in enumerate(row, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=val)
                
                if is_header:
                    cell.font = Font(bold=True, size=10)
                    cell.fill = PatternFill(start_color="F4F8FC", end_color="F4F8FC", fill_type="solid")
                elif is_total:
                    cell.font = Font(bold=True, size=10)
                    cell.fill = PatternFill(start_color="FAFAFA", end_color="FAFAFA", fill_type="solid")
                else:
                    cell.font = Font(size=10)
                    if row_idx % 2 == 0:
                        cell.fill = PatternFill(start_color="F8F9FA", end_color="F8F9FA", fill_type="solid")
                
                if col_idx == 1:
                    cell.alignment = Alignment(horizontal="left", vertical="center")
                else:
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                    
                cell.border = openpyxl.styles.Border(bottom=openpyxl.styles.Side(style='hair', color='E0E0E0'))

        ws.column_dimensions['A'].width = 70
        for col in 'BCDEF':
            ws.column_dimensions[col].width = 25

        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)
        excel_bytes = buf.getvalue()

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao gerar Excel: {e}")
        
    return Response(content=excel_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="relatorio_{tipo}_{ano}.xlsx"'})

@app.get("/download/pptx/{tipo}")
async def download_pptx(tipo: str, ano: int = Query(2026), periodo: str = Query("Jan-Set")):
    try:
        prs = Presentation()
        prs.slide_width = Inches(10)
        prs.slide_height = Inches(7.5)

        csv_path = _get_csv_por_tipo(tipo)
        if not csv_path:
            raise HTTPException(status_code=404, detail="CSV não encontrado.")
        
        dados_csv = _ler_csv_generico(csv_path)
        while dados_csv and not any(str(c).strip() for c in dados_csv[-1]):
            dados_csv.pop()
        
        header_idx = 0
        max_cols = 6
        for i, row in enumerate(dados_csv):
            row_str = " ".join(row).upper()
            if "ESPECIFICA" in row_str or "RECEITAS ORCAMENT" in row_str:
                header_idx = i
                max_cols = max(len(row), 6)
                break

        data_rows = dados_csv[header_idx+1:]
        POR_SLIDE = 30
        total_slides = max(1, (len(data_rows) + POR_SLIDE - 1) // POR_SLIDE)
        
        for pag in range(total_slides):
            slide = prs.slides.add_slide(prs.slide_layouts[6])
            fatia = data_rows[pag*POR_SLIDE : (pag+1)*POR_SLIDE]
            
            n_linhas = len(fatia) + 1
            shape = slide.shapes.add_table(n_linhas, max_cols, Inches(0.2), Inches(0.2), Inches(9.6), Inches(0.2) * n_linhas)
            tbl = shape.table
            
            # Header
            header_row = dados_csv[header_idx]
            for j in range(max_cols):
                cell = tbl.cell(0, j)
                cell.text = header_row[j][:30] if j < len(header_row) else ""
                for pr in cell.text_frame.paragraphs:
                    for r in pr.runs:
                        r.font.bold = True
                        r.font.size = Inches(0.08)

            for i, row in enumerate(fatia, start=1):
                for j in range(max_cols):
                    text = row[j] if j < len(row) else ""
                    text = text.encode('latin-1', 'replace').decode('latin-1')
                    cell = tbl.cell(i, j)
                    cell.text = text[:40]
                    for pr in cell.text_frame.paragraphs:
                        for r in pr.runs:
                            r.font.size = Inches(0.07)
                            if any(k in text.upper() for k in ["ATIVO", "PASSIVO", "TOTAL", "ESPECIFICAÇÃO", "RECEITAS"]):
                                r.font.bold = True
                            if j > 0:
                                pr.alignment = PP_ALIGN.RIGHT

        buf = io.BytesIO(); prs.save(buf); buf.seek(0)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao gerar PPTX: {e}")
        
    return Response(content=buf.getvalue(), media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        headers={"Content-Disposition": f'attachment; filename="relatorio_{tipo}_{ano}.pptx"'})

@app.post("/upload")
async def upload_arquivo(file: UploadFile = File(...)):
    caminho = os.path.join(UPLOAD_DIR, file.filename)
    with open(caminho, "wb") as b: shutil.copyfileobj(file.file, b)
    return {"filename": file.filename, "status": "sucesso"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)